var CONFIG = {
    "androidUrl": "",
    "appleUrl": "",
    "amazonUrl": "",
    "gameEvents": {
        "time-after-interaction": {
            "time": 15000,
            "cta": false,
            "activation": "interaction"
        },
        "interaction": {
            "interactions": 30,
            "cta": false
        },
        "time": {
            "time": 30000,
            "cta": true
        },
        "time-after-outro": {
            "time": 5000,
            "cta": true,
            "activation": "outro"
        }
    },
    "I18": {
        "locale": "en",
        "strings": {
            "outro-l": {
                "en": "DESTROY MORE PINATAS!"
            },
            "outro-p": {
                "en": "DESTROY MORE\nPINATAS!"
            },
            "continue": {
                "en": "CONTINUE"
            },
            "download": {
                "en": "DOWNLOAD"
            },
            "tutorial-top": {
                "en": "DESTROY THE"
            },
            "tutorial-bottom": {
                "en": "PINATA!"
            }
        }
    },
    "application": {
        "showFPS": false,
        "skipOutro": false
    }, 
    "game": {
        noInteractionTimer: 8000,
        tutorialTimer: 3000,
        progressBar: {
            hitCost: 20
        }
    },
    "textStyles": {
        "fontFamily": "arkabal",
        "cta": {
            align: "center",
            fill: "white",
            fontSize: 90
        },
        "outro": {
            align: "center",
            fill: "white",
            fontSize: 90
        }, 
        "scoreBar": {
            align: "center",
            fill: "white",
            fontSize: 40,
            fontWeight: 600,
            stroke: "#008040",
            strokeThickness: 1
        },
        "tutorialTop": {
            fill: "0xffffff",
            fontSize: 70,
            fontWeight: 600,
            letterSpacing: 5,
            stroke: "#6f3daf",
            strokeThickness: 10,
            padding: 20
        },
        "tutorialBottom": {
            fill: "0xffffff",
            fontSize: 80,
            fontWeight: 600,
            letterSpacing: 5,
            stroke: "#6f3daf",
            strokeThickness: 10,
            padding: 20
        }
    }
};