var CONFIG = {
    closeButtonTimer: 5000,
    endGameTimer: 60000
};


var TYPE = {
    UNKNOW: 0, 
    CARROT: 1, COW: 2, PIG: 3, STRAWBERRY: 4, BLUEBERRY: 5, 
    CORN: 6, POTATO: 7, CHICKEN: 8, RASPBERRY: 9,
    PLANT: 10, ANIMAL: 11,
};
var GAME_CONFIG = {
    FARM_POINTS: [
    /////////////////
    //     .1.     //
    //   .4...2.   //
    // .7...5...3. //
    //   .8...6.   //
    //     .9.     //
    /////////////////
    {//#1, RASPBERRY
        type: TYPE.RASPBERRY,
        cost: 888000000000000000000,
        productionTime: 10000,
        /*base*/income: 100000000000000000000,
        /*base*/upgrade: 20000000000000000,
        incomeInc: 20000000000000000000,
        upgradeInc: 5000000000000000
    },{//#2, CHICKEN
        type: TYPE.CHICKEN,
        cost: 70000000000000000,
        productionTime: 8000,
        /*base*/income: 100000000000000000,
        /*base*/upgrade: 10000000000,
        incomeInc: 40000000000000000,
        upgradeInc: 3000000000
    },{//#3, POTATO
        type: TYPE.POTATO,
        cost: 1900000000000,
        productionTime: 6500,
        /*base*/income: 10000000000000,
        /*base*/upgrade: 5000000000,
        incomeInc: 3000000000000,
        upgradeInc: 1000000000
    },{//#4 CORN
        type: TYPE.CORN,
        cost: /*0,//*/3180000000,
        productionTime: 5000,
        /*base*/income: 20000000000,
        /*base*/upgrade: 2000000,
        incomeInc: 2000000000,
        upgradeInc: 1000000
    },{//#5 BLUEBERRY
        type: TYPE.BLUEBERRY,
        cost: /*0,//*/21000000,
        productionTime: 3500,
        /*base*/income: 50000000,
        /*base*/upgrade: 200000,
        incomeInc: 20000000,
        upgradeInc: 100000
    },{//#6 STRAWBERRYES
        type: TYPE.STRAWBERRY,
        cost: /*0,//*/42000,
        productionTime: 2400,
        /*base*/income: 300000,
        /*base*/upgrade: 4000,
        incomeInc: 300000,
        upgradeInc: 1000
    },{//#7 PIGS
        type: TYPE.PIG,
        cost: /*0,//*/720,
        productionTime: 1600,
        /*base*/income: 1500,
        /*base*/upgrade: 240,
        incomeInc: 3000,
        upgradeInc: 100
    },{//#8 COWS
        type: TYPE.COW,
        cost: /*0,//*/60,
        productionTime: 900,
        /*base*/income: 150,
        /*base*/upgrade: 60,
        incomeInc: 100,
        upgradeInc: 30
    },{//#9 CARROTS
        type: TYPE.CARROT,
        cost: 0,
        productionTime: 300,
        /*base*/income: 5,
        /*base*/upgrade: 3,
        incomeInc: 5,
        upgradeInc: 2
    }
    ]
};
