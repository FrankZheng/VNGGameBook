var colourThemes = {
    black: {
        cta: '#009aff'
    },
    purple: {
        cta: '#622762'
    },
    blue: {
        cta: '#009aff'
    },
    green: {
        cta: '#05c237'
    },
    red: {
        cta: '#e50606'
    },
    orange: {
        cta: '#ffb800'
    }
}

var defaultTheme = 'green' // Do not edit this.
var defaultIcon = 'download' // Do not edit this.
