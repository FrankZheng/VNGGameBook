        function startCarousel() {
            if ($('.slick-initialized').length > 0) {
                $('.center').slick('unslick');
            } else {
                $('.slider').on('beforeChange', function(event, slick, currentSlide, nextSlide) {
                    var cloneID = nextSlide + slideCount;
                    $('.active-clone').removeClass('active-clone');
                    $('*[data-slick-index="' + cloneID + '"]').addClass('active-clone');

                    var nextSlideDiv = $('*[data-slick-index="' + nextSlide + '"]')[0];
                    var customBG = $(nextSlideDiv).find('.content').attr('custom-bg')
                    if (customBG.length > 0) {
                        setBackground(customBG)
                    } else {
                        $('.custom-bg').css('opacity', '0');
                    }

                });
            }

            var slideCount = $('.center > div ').length
            $('.center').slick({
                centerMode: true,
                centerPadding: setupPadding(),
                slidesToShow: 1,
                autoplay: true,
                autoplaySpeed: 1200,
                pauseOnFocus: true
            });


        }

        var backgroundCounter = false;

        function setBackground(input) {
            if (typeof backgroundSelector == 'undefined') {
                var backgroundSelectorOne = $('.custom-bg')[0];
                var backgroundSelectorTwo = $('.custom-bg')[1];
            }
            if (backgroundCounter) {
                backgroundSelectorOne.style.backgroundImage = "url(" + input + ")";
                backgroundSelectorOne.style.opacity = 1;
                setTimeout(function() {
                    backgroundSelectorTwo.style.opacity = 0;
                }, 100);
            } else {
                backgroundSelectorTwo.style.backgroundImage = "url(" + input + ")";
                backgroundSelectorTwo.style.opacity = 1;
                setTimeout(function() {
                    backgroundSelectorOne.style.opacity = 0;
                }, 100);
            }
            backgroundCounter = !backgroundCounter;
        }


        function setupPadding() {
            var imageDimensions = $('#ad-unit').hasClass('portrait') ? 'portrait' : 'landscape';
            var deviceOrientation = orientationCheck();
            var aspectRatio = window.innerHeight / window.innerWidth;

            if (getLargestAspectRatio() > 1.2 && getLargestAspectRatio() < 1.4) {
                switch (deviceOrientation + '-' + imageDimensions) {
                    case 'portrait-portrait':
                        return parseInt((340 / (getLargestAspectRatio() * 1))) + 'px';;
                    case 'portrait-landscape':
                        return '135px'
                    case 'landscape-portrait':
                        return parseInt((250 / getLargestAspectRatio())) + 'px';
                        // return '190px'
                    case 'landscape-landscape':
                        // return parseInt((4 / getLargestAspectRatio())) + 'px';

                    default:
                }
            } else {
                switch (deviceOrientation + '-' + imageDimensions) {
                    case 'portrait-portrait':
                        // return parseInt((190 / (getLargestAspectRatio() * 1))) + 'px';
                        return '26vw'
                    case 'portrait-landscape':
                        return '10vw'
                    case 'landscape-portrait':
                        return '20vw'
                    case 'landscape-landscape':
                        return '9.5vw'
                    default:
                }
            }
        }

        startCarousel();

        function getLargestAspectRatio() {
            var w = window.innerWidth;
            var h = window.innerHeight;
            console.log((w <= h) ? (h / w) : (w / h));
            return (w <= h) ? (h / w) : (w / h);
        }


        window.addEventListener('resize', function() {
            startCarousel()
        }, true);